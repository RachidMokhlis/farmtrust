module.exports = require('./_all_routes').ordersRouter;
